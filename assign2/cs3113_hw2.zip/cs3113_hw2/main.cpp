/**
* Author: Bo Wen
* 
* 
* Assignment: Pong Clone
* Date due: 2025-3-01, 11:59pm
* I pledge that I have completed this assignment without
* collaborating with anyone else, in conformance with the
* NYU School of Engineering Policies and Procedures on
* Academic Misconduct.
**/


#define GL_SILENCE_DEPRECATION
#define STB_IMAGE_IMPLEMENTATION
#define LOG(argument) std::cout << argument << '\n'

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#define GL_GLEXT_PROTOTYPES 1
#include <SDL.h>
#include <SDL_opengl.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"
#include "stb_image.h"
#include "cmath"
#include <ctime>

enum AppStatus { RUNNING, TERMINATED };

constexpr float WINDOW_SIZE_MULT = 1.0f;

constexpr int WINDOW_WIDTH = 640 * WINDOW_SIZE_MULT,
WINDOW_HEIGHT = 480 * WINDOW_SIZE_MULT;

constexpr float BG_RED = 0.9765625f,
BG_GREEN = 0.97265625f,
BG_BLUE = 0.9609375f,
BG_OPACITY = 1.0f;

constexpr int VIEWPORT_X = 0,
VIEWPORT_Y = 0,
VIEWPORT_WIDTH = WINDOW_WIDTH,
VIEWPORT_HEIGHT = WINDOW_HEIGHT;

constexpr char V_SHADER_PATH[] = "shaders/vertex_textured.glsl",
F_SHADER_PATH[] = "shaders/fragment_textured.glsl";

constexpr float MILLISECONDS_IN_SECOND = 1000.0;

constexpr char PADDLE1_SPRITE_FILEPATH[] = "pingpong1.png",
PADDLE2_SPRITE_FILEPATH[] = "pingpong2.png",
BALL_SPRITE_FILEPATH[] = "ball.png",
WINNER1_SPRITE_FILEPATH[] = "winner1.png",
WINNER2_SPRITE_FILEPATH[] = "winner2.png";

constexpr int MAX_BALL = 3;


glm::mat4 g_view_matrix, g_projection_matrix;

SDL_Window* g_display_window;
AppStatus g_app_status = RUNNING;
ShaderProgram g_shader_program = ShaderProgram();
float g_previous_ticks = 0.0f;

struct GameObject {
    glm::vec3 position;
    glm::vec3 movement;
    glm::vec3 scale;
    GLuint texture_id;
};

GameObject g_balls[MAX_BALL];
int g_currentball = 1; 

GameObject g_paddle1; 
GameObject g_paddle2;

GLuint g_paddle1_texture_id;
GLuint g_paddle2_texture_id;
GLuint g_winner1_texture_id;
GLuint g_winner2_texture_id;

bool g_singleMode = false;
bool g_Over = false;
int  g_winner = 0;


constexpr float PADDLE_SPEED = 10.0f;
constexpr float BALL_SPEED = 3.0f;

constexpr float LEFT_BOUND = -5.0f;
constexpr float RIGHT_BOUND = 5.0f;
constexpr float TOP_BOUND = 3.75f;
constexpr float BOTTOM_BOUND = -3.75f;


constexpr float PADDLE1_SCALE_X = 1.2f;
constexpr float PADDLE1_SCALE_Y = 1.0f;

constexpr float PADDLE2_SCALE_X = 1.35f;
constexpr float PADDLE2_SCALE_Y = 1.0f;

constexpr float BALL_SCALE_X = 0.55f;
constexpr float BALL_SCALE_Y = 0.50f;


void initialise();
void process_input();
void update();
void render();
void shutdown();




constexpr GLint NUMBER_OF_TEXTURES = 1;  // to be generated, that is
constexpr GLint LEVEL_OF_DETAIL = 0;  // base image level; Level n is the nth mipmap reduction image
constexpr GLint TEXTURE_BORDER = 0;  // this value MUST be zero
GLuint load_texture(const char* filepath)
{
    // STEP 1: Loading the image file
    int width, height, number_of_components;
    unsigned char* image = stbi_load(filepath, &width, &height, &number_of_components, STBI_rgb_alpha);

    if (image == NULL)
    {
        LOG("Unable to load image. Make sure the path is correct.");
        assert(false);
    }

    // STEP 2: Generating and binding a texture ID to our image
    GLuint textureID;
    glGenTextures(NUMBER_OF_TEXTURES, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexImage2D(GL_TEXTURE_2D, LEVEL_OF_DETAIL, GL_RGBA, width, height, TEXTURE_BORDER, GL_RGBA, GL_UNSIGNED_BYTE, image);

    // STEP 3: Setting our texture filter parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    // STEP 4: Releasing our file from memory and returning our texture id
    stbi_image_free(image);

    return textureID;
}

void initialise()
{
    SDL_Init(SDL_INIT_VIDEO);
    g_display_window = SDL_CreateWindow("PING PONG!",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        WINDOW_WIDTH, WINDOW_HEIGHT,
        SDL_WINDOW_OPENGL);

    SDL_GLContext context = SDL_GL_CreateContext(g_display_window);
    SDL_GL_MakeCurrent(g_display_window, context);


    if (g_display_window == nullptr)
    {
        shutdown();
    }
#ifdef _WINDOWS
    glewInit();
#endif

    glViewport(VIEWPORT_X, VIEWPORT_Y, VIEWPORT_WIDTH, VIEWPORT_HEIGHT);

    g_shader_program.load(V_SHADER_PATH, F_SHADER_PATH);

    g_view_matrix = glm::mat4(1.0f);
    g_projection_matrix = glm::ortho(-5.0f, 5.0f, -3.75f, 3.75f, -1.0f, 1.0f);

    g_shader_program.set_projection_matrix(g_projection_matrix);
    g_shader_program.set_view_matrix(g_view_matrix);

    glUseProgram(g_shader_program.get_program_id());
    glClearColor(BG_RED, BG_GREEN, BG_BLUE, BG_OPACITY);

    GLuint paddle_texture_id1 = load_texture(PADDLE1_SPRITE_FILEPATH);
    GLuint paddle_texture_id2 = load_texture(PADDLE2_SPRITE_FILEPATH);
    GLuint ball_texture_id = load_texture(BALL_SPRITE_FILEPATH);
    g_winner1_texture_id = load_texture(WINNER1_SPRITE_FILEPATH);
    g_winner2_texture_id = load_texture(WINNER2_SPRITE_FILEPATH);



    // enable blending
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    g_paddle1.position = glm::vec3(-4.0f, 0.0f, 0.0f);
    g_paddle1.movement = glm::vec3(0.0f);
    g_paddle1.scale = glm::vec3(PADDLE1_SCALE_X, PADDLE1_SCALE_Y, 1.0f);
    g_paddle1.texture_id = paddle_texture_id1;

    g_paddle2.position = glm::vec3(4.0f, 0.0f, 0.0f);
    g_paddle2.movement = glm::vec3(0.0f);
    g_paddle2.scale = glm::vec3(PADDLE2_SCALE_X, PADDLE2_SCALE_Y, 1.0f);
    g_paddle2.texture_id = paddle_texture_id2;

    for (int i = 0; i < MAX_BALL; ++i) {
        g_balls[i].position = glm::vec3(0.0f, 0.0f, 0.0f);

        g_balls[i].movement = glm::vec3((i % 2 == 0) ? BALL_SPEED : -BALL_SPEED, BALL_SPEED, 0.0f);
        g_balls[i].scale = glm::vec3(BALL_SCALE_X, BALL_SCALE_Y, 1.0f);
        g_balls[i].texture_id = ball_texture_id;
    }

    g_currentball = 1; 

    // Game state
    g_Over = false;
    g_winner = 0;

}



void process_input()
{
    if (g_Over) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT || event.type == SDL_WINDOWEVENT_CLOSE) {
                g_app_status = TERMINATED;
            }
        }
        return;
    }

    SDL_Event event;
    while (SDL_PollEvent(&event))
    {
        switch (event.type)
        {
        case SDL_QUIT:
        case SDL_WINDOWEVENT_CLOSE:
            g_app_status = TERMINATED;
            break;

        case SDL_KEYDOWN:
            switch (event.key.keysym.sym)
            {
            case SDLK_t:
                // Toggle player mode
                g_singleMode = !g_singleMode;
                break;
            case SDLK_1:
                g_currentball = 1;
                break;
            case SDLK_2:
                g_currentball = 2;
                break;
            case SDLK_3:
                g_currentball = 3;
                break;
            default:
                break;
            }

        default:
            break;
        }
    }

    g_paddle1.movement = glm::vec3(0.0f);
    g_paddle2.movement = glm::vec3(0.0f);

    const Uint8* key_state = SDL_GetKeyboardState(NULL);



    //player1:
    if (key_state[SDL_SCANCODE_W])
    {
        g_paddle1.movement.y = 1.0f;
    }
    else if (key_state[SDL_SCANCODE_S])
    {
        g_paddle1.movement.y = -1.0f;
    }

    //player2"
    if (!g_singleMode) {
        if (key_state[SDL_SCANCODE_UP])
        {
            g_paddle2.movement.y = 1.0f;
        }
        else if (key_state[SDL_SCANCODE_DOWN])
        {
            g_paddle2.movement.y = -1.0f;
        }
    }

}

bool collisionCheck(const GameObject& a, const GameObject& b) {
    float x_distance = fabs(a.position.x - b.position.x) - ((a.scale.x + b.scale.x) / 2.0f);
    float y_distance = fabs(a.position.y - b.position.y) - ((a.scale.y + b.scale.y) / 2.0f);

    return (x_distance < 0.0f && y_distance < 0.0f);

}


float g_paddle2Auto = 1.0f;
void update()
{
    if (g_Over) return;

    float ticks = (float)SDL_GetTicks() / MILLISECONDS_IN_SECOND; // get the current number of ticks
    float delta_time = ticks - g_previous_ticks; // the delta time is the difference from the last frame
    g_previous_ticks = ticks;

    g_paddle1.position += g_paddle1.movement * PADDLE_SPEED * delta_time;

    float paddle1Mid = g_paddle1.scale.y / 2.0f;
    if (g_paddle1.position.y + paddle1Mid > TOP_BOUND) {
        g_paddle1.position.y = TOP_BOUND - paddle1Mid;
    }
    else if (g_paddle1.position.y - paddle1Mid < BOTTOM_BOUND) {
        g_paddle1.position.y = BOTTOM_BOUND + paddle1Mid;
    }

    if (g_singleMode) {
        g_paddle2.position.y += g_paddle2Auto * PADDLE_SPEED * delta_time; 
        float paddle2Mid = g_paddle2.scale.y / 2.0f;
        if (g_paddle2.position.y + paddle2Mid > TOP_BOUND) {
            g_paddle2.position.y = TOP_BOUND - paddle2Mid;
            g_paddle2Auto *= -1.0f;
        }
        else if (g_paddle2.position.y - paddle2Mid < BOTTOM_BOUND) {
            g_paddle2.position.y = BOTTOM_BOUND + paddle2Mid;
            g_paddle2Auto *= -1.0f;
        }
    }
    else {
        g_paddle2.position += g_paddle2.movement * PADDLE_SPEED * delta_time;
        float paddle2Mid = g_paddle2.scale.y / 2.0f;
        if (g_paddle2.position.y + paddle2Mid > TOP_BOUND) {
            g_paddle2.position.y = TOP_BOUND - paddle2Mid;
        }
        else if (g_paddle2.position.y - paddle2Mid < BOTTOM_BOUND) {
            g_paddle2.position.y = BOTTOM_BOUND + paddle2Mid;
        }
    }


    for (int i = 0; i < g_currentball; i++) {
        g_balls[i].position += g_balls[i].movement * delta_time;

        float ballMid = g_balls[i].scale.y / 2.0f;
        if (g_balls[i].position.y + ballMid > TOP_BOUND) {
            g_balls[i].position.y = (TOP_BOUND - ballMid);
            g_balls[i].movement.y *= -1.0f;
        }
        else if (g_balls[i].position.y - ballMid < BOTTOM_BOUND) {
            g_balls[i].position.y = BOTTOM_BOUND + ballMid;
            g_balls[i].movement.y *= -1.0f;
        }

        float ballLeft = g_balls[i].position.x - (g_balls[i].scale.x / 2.0f);
        float ballRight = g_balls[i].position.x + (g_balls[i].scale.x / 2.0f);

        if (ballLeft < LEFT_BOUND) {
            //player2 wins
            g_Over = true;
            g_winner = 2;
            return;
        }
        else if (ballRight > RIGHT_BOUND) {
            //Player1 wins
            g_Over = true;
            g_winner = 1;
            return;
        }

        if (collisionCheck(g_balls[i], g_paddle1)) {
            g_balls[i].movement.x = fabs(g_balls[i].movement.x);
        }
        if (collisionCheck(g_balls[i], g_paddle2)) {
            g_balls[i].movement.x = -fabs(g_balls[i].movement.x);
        }

    }
}
    
void draw_object(const GameObject & obj)
{
    glm::mat4 model = glm::mat4(1.0f);
    model = glm::translate(model, obj.position);
    model = glm::scale(model, obj.scale);
    g_shader_program.set_model_matrix(model);

    glBindTexture(GL_TEXTURE_2D, obj.texture_id);
    glDrawArrays(GL_TRIANGLES, 0, 6); // we are now drawing 2 triangles, so we use 6 instead of 3
}
void draw_winner() {
    if (!g_Over) return;
    if (g_winner != 1 && g_winner != 2) return;

    GLuint winner = (g_winner == 1) ? g_winner1_texture_id : g_winner2_texture_id;

    glm::mat4 model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f));
    model = glm::scale(model, glm::vec3(5.0f, 3.0f, 1.0f));  
    g_shader_program.set_model_matrix(model);

    glBindTexture(GL_TEXTURE_2D, winner);
    glDrawArrays(GL_TRIANGLES, 0, 6);
}


void render() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Vertices
    float vertices[] = {
        -0.5f, -0.5f, 0.5f, -0.5f, 0.5f, 0.5f,  // triangle 1
        -0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f   // triangle 2
    };

    // Textures
    float texture_coordinates[] = {
        0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,     // triangle 1
        0.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f,     // triangle 2
    };

    glVertexAttribPointer(g_shader_program.get_position_attribute(), 2, GL_FLOAT, false, 0, vertices);
    glEnableVertexAttribArray(g_shader_program.get_position_attribute());

    glVertexAttribPointer(g_shader_program.get_tex_coordinate_attribute(), 2, GL_FLOAT, false, 0, texture_coordinates);
    glEnableVertexAttribArray(g_shader_program.get_tex_coordinate_attribute());

    // Bind texture
    draw_object(g_paddle1);
    draw_object(g_paddle2);

    for (int i = 0; i < g_currentball; i++) {
        draw_object(g_balls[i]);
    }

    if (g_Over) {
        draw_winner();
    }

    // We disable two attribute arrays now
    glDisableVertexAttribArray(g_shader_program.get_position_attribute());
    glDisableVertexAttribArray(g_shader_program.get_tex_coordinate_attribute());

    SDL_GL_SwapWindow(g_display_window);
}

void shutdown() { SDL_Quit(); }


int main(int argc, char* argv[])
{
    initialise();

    while (g_app_status == RUNNING)
    {
        process_input();
        update();
        render();
    }

    shutdown();
    return 0;
}