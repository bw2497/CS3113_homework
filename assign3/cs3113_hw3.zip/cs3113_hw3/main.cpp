﻿/**
* Author: Bo Wen
* Assignment : Lunar Lander
* Date due : 2025 - 3 - 15, 11 : 59pm
* I pledge that I have completed this assignment without
* collaborating with anyone else, in conformance with the
* NYU School of Engineering Policies and Procedures on
* Academic Misconduct.
**/

#define LOG(argument) std::cout << argument << '\n'
#define STB_IMAGE_IMPLEMENTATION
#define GL_SILENCE_DEPRECATION
#define GL_GLEXT_PROTOTYPES 1

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#include <SDL.h>
#include <SDL_opengl.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"
#include "stb_image.h"
#include "cmath"
#include <ctime>
#include <vector>
#include "Entity.h"
#include <iostream>     

// ————— CONSTANTS ————— //
constexpr int WINDOW_WIDTH = 640,
WINDOW_HEIGHT = 480;

constexpr float BG_RED = 0.1922f,
BG_BLUE = 0.549f,
BG_GREEN = 0.9059f,
BG_OPACITY = 1.0f;

constexpr int VIEWPORT_X = 0,
VIEWPORT_Y = 0,
VIEWPORT_WIDTH = WINDOW_WIDTH,
VIEWPORT_HEIGHT = WINDOW_HEIGHT;

constexpr char V_SHADER_PATH[] = "shaders/vertex_textured.glsl",
F_SHADER_PATH[] = "shaders/fragment_textured.glsl";

constexpr float MILLISECONDS_IN_SECOND = 1000.0;
constexpr float FIXED_TIMESTEP = 1.0f / 60.0f;

constexpr char  SPRITESHEET_FILEPATH[] = "george_0.png",
PLATFORM_FILEPATH[] = "platformPack_tile027.png",
WINNINGPLATFORM_FILEPATH[] = "platformPack_tile028.png";

constexpr char  FONT_TEXTURE_PATH[] = "font1.png";
constexpr int FONTBANK_SIZE = 16;

constexpr GLint NUMBER_OF_TEXTURES = 1;
constexpr GLint LEVEL_OF_DETAIL = 0;
constexpr GLint TEXTURE_BORDER = 0;

constexpr float ACC_OF_GRAVITY = -9.81f *0.1f;

constexpr float UP_ACCEL = 5.0f;    
constexpr float FUEL_USAGE_PER_SEC = 10.0f; 

constexpr float HORIZONTAL_ACCEL = 3.0f;  
constexpr int   PLATFORM_COUNT = 6;

bool g_Over = false;
int mission=0;

// ————— STRUCTS AND ENUMS —————//
enum AppStatus { RUNNING, TERMINATED };

struct GameState
{
    Entity* player;
    Entity* platforms;
    GLuint font_texture_id;
};

// ————— VARIABLES ————— //
GameState g_game_state;

SDL_Window* g_display_window;
AppStatus g_app_status = RUNNING;

ShaderProgram g_shader_program = ShaderProgram();
glm::mat4 g_view_matrix, g_projection_matrix;

float g_previous_ticks = 0.0f;
float g_time_accumulator = 0.0f;

// ———— GENERAL FUNCTIONS ———— //
GLuint load_texture(const char* filepath);

void initialise();
void process_input();
void update();
void render();
void shutdown();

void draw_text(ShaderProgram* shader_program, GLuint font_texture_id, std::string text,
    float font_size, float spacing, glm::vec3 position);

GLuint load_texture(const char* filepath)
{
    int width, height, number_of_components;
    unsigned char* image = stbi_load(filepath, &width, &height, &number_of_components,
        STBI_rgb_alpha);

    if (image == NULL)
    {
        LOG("Unable to load image. Make sure the path is correct.");
        assert(false);
    }

    GLuint textureID;
    glGenTextures(NUMBER_OF_TEXTURES, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexImage2D(GL_TEXTURE_2D, LEVEL_OF_DETAIL, GL_RGBA, width, height, TEXTURE_BORDER,
        GL_RGBA, GL_UNSIGNED_BYTE, image);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    stbi_image_free(image);

    return textureID;
}

void initialise()
{
    SDL_Init(SDL_INIT_VIDEO);
    g_display_window = SDL_CreateWindow("Moon Landers",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        WINDOW_WIDTH, WINDOW_HEIGHT,
        SDL_WINDOW_OPENGL);

    SDL_GLContext context = SDL_GL_CreateContext(g_display_window);
    SDL_GL_MakeCurrent(g_display_window, context);

    if (context == nullptr)
    {
        LOG("ERROR: Could not create OpenGL context.\n");
        shutdown();
    }

#ifdef _WINDOWS
    glewInit();
#endif

    glViewport(VIEWPORT_X, VIEWPORT_Y, VIEWPORT_WIDTH, VIEWPORT_HEIGHT);

    g_shader_program.load(V_SHADER_PATH, F_SHADER_PATH);

    g_view_matrix = glm::mat4(1.0f);
    g_projection_matrix = glm::ortho(-5.0f, 5.0f, -3.75f, 3.75f, -1.0f, 1.0f);

    g_shader_program.set_projection_matrix(g_projection_matrix);
    g_shader_program.set_view_matrix(g_view_matrix);

    glUseProgram(g_shader_program.get_program_id());

    glClearColor(BG_RED, BG_BLUE, BG_GREEN, BG_OPACITY);

    // ————— PLAYER ————— //
    GLuint player_texture_id = load_texture(SPRITESHEET_FILEPATH);

     int player_walking_animation[4][4] =
    {
        { 1, 5, 9,  13 }, // LEFT
        { 3, 7, 11, 15 }, // RIGHT
        { 2, 6, 10, 14 }, // UP
        { 0, 4, 8,  12 }  // DOWN
    };

    g_game_state.player = new Entity(
        player_texture_id,         // texture id
        1.0f,                      // speed
        player_walking_animation,  // animation sets
        0.0f,                      // animation time
        4,                         // animation frame count
        0,                         // current animation index
        4,                         // animation cols
        4                          // animation rows
    );

     g_game_state.player->set_acceleration(glm::vec3(0.0f, ACC_OF_GRAVITY, 0.0f));
     g_game_state.player->set_fuel(100.0f); 
     g_game_state.player->face_right();     // default



     g_game_state.platforms = new Entity[PLATFORM_COUNT];

     for (int i = 0; i < PLATFORM_COUNT; i++)
      {
        g_game_state.platforms[i].set_texture_id(load_texture(PLATFORM_FILEPATH));
        g_game_state.platforms[i].set_position(glm::vec3(i - 1.0f, -3.0f, 0.0f));
        g_game_state.platforms[i].update(0.0f, nullptr, 0);
    }

     GLuint win_platform_tex = load_texture(WINNINGPLATFORM_FILEPATH);

     g_game_state.platforms[3].set_texture_id(win_platform_tex);
     g_game_state.platforms[3].set_position(glm::vec3(-2.5f, 1.5f, 0.0f));

     g_game_state.platforms[3].set_velocity(glm::vec3(1.0f, 0.0f, 0.0f));
     g_game_state.platforms[3].update(0.0f, nullptr, 0);

     g_game_state.platforms[4].set_texture_id(win_platform_tex);
     g_game_state.platforms[4].set_position(glm::vec3(-4.5f, 0.8f, 0.0f));

     g_game_state.platforms[4].set_velocity(glm::vec3(0.5f, 0.0f, 0.0f));
     g_game_state.platforms[4].update(0.0f, nullptr, 0);

     g_game_state.platforms[5].set_texture_id(win_platform_tex);
     g_game_state.platforms[5].set_position(glm::vec3(4.5f, -1.5f, 0.0f));

     g_game_state.platforms[5].set_velocity(glm::vec3(1.0f, 0.0f, 0.0f));
     g_game_state.platforms[5].update(0.0f, nullptr, 0);


     g_game_state.font_texture_id = load_texture(FONT_TEXTURE_PATH);
    // ————— GENERAL ————— //
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    g_app_status = RUNNING;
    g_previous_ticks = (float)SDL_GetTicks() / MILLISECONDS_IN_SECOND;
    g_time_accumulator = 0.0f;

    g_Over = false;
    mission = 0;
}

void process_input()
{
    if (g_Over) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT || event.type == SDL_WINDOWEVENT_CLOSE) {
                g_app_status = TERMINATED;
            }
        }
        return;
    }
    // VERY IMPORTANT: If nothing is pressed, we don't want to go anywhere
    g_game_state.player->set_movement(glm::vec3(0.0f));

    SDL_Event event;
    while (SDL_PollEvent(&event))
    {
        switch (event.type) {
            // End game
        case SDL_QUIT:
        case SDL_WINDOWEVENT_CLOSE:
            g_app_status = TERMINATED;
            break;

        case SDL_KEYDOWN:
            switch (event.key.keysym.sym) {
            case SDLK_q:
                // Quit the game with a keystroke
                g_app_status = TERMINATED;
                break;

            default:
                break;
            }

        default:
            break;
        }
    }

    glm::vec3 old_accel = g_game_state.player->get_acceleration();
    glm::vec3 old_velocity = g_game_state.player->get_velocity();
    float current_fuel = g_game_state.player->get_fuel();
    
    float new_ax = 0.0f;
    float new_ay = ACC_OF_GRAVITY;

    const Uint8* key_state = SDL_GetKeyboardState(NULL);

    if (key_state[SDL_SCANCODE_LEFT]) {
        new_ax = -HORIZONTAL_ACCEL;
    }
    else if (key_state[SDL_SCANCODE_RIGHT]) {
        new_ax = HORIZONTAL_ACCEL;
    }

    bool pressing_up = (key_state[SDL_SCANCODE_UP] && current_fuel > 0.0f);
    if (pressing_up)
    {
        new_ay += UP_ACCEL;
        float fuel_burn_per_frame = FUEL_USAGE_PER_SEC * FIXED_TIMESTEP;
        current_fuel -= fuel_burn_per_frame;
        if (current_fuel < 0.0f) {
            current_fuel = 0.0f;
        }
    }
    else
    {
        if (old_velocity.y > 0.0f)
        {
            old_velocity.y = 0.0f;
            g_game_state.player->set_velocity(old_velocity);
        }

    }

    // Reassign final acceleration and fuel
    g_game_state.player->set_acceleration(glm::vec3(new_ax, new_ay, 0.0f));
    g_game_state.player->set_fuel(current_fuel);

    g_game_state.player->set_movement(glm::vec3(0.0f));
    if (key_state[SDL_SCANCODE_LEFT])  g_game_state.player->move_left();
    if (key_state[SDL_SCANCODE_RIGHT]) g_game_state.player->move_right();
    if (pressing_up)                   g_game_state.player->move_up();



    // Avoid faster diagonal animation if multiple keys are pressed
    if (glm::length(g_game_state.player->get_movement()) > 1.0f) {
        g_game_state.player->normalise_movement();
    }

}

void update()
{

    if (g_Over) return;

    // ————— DELTA TIME ————— //
    float ticks = (float)SDL_GetTicks() / MILLISECONDS_IN_SECOND;
    float delta_time = ticks - g_previous_ticks;
    g_previous_ticks = ticks;

    // ————— FIXED TIMESTEP ————— //
    // STEP 1: Keep track of how much time has passed since last step
    delta_time += g_time_accumulator;

    // STEP 2: Accumulate the ammount of time passed while we're under our fixed timestep
    if (delta_time < FIXED_TIMESTEP)
    {
        g_time_accumulator = delta_time;
        return;
    }

    // STEP 3: Once we exceed our fixed timestep, apply that elapsed time into the 
    //         objects' update function invocation
    while (delta_time >= FIXED_TIMESTEP)
    {
        // Notice that we're using FIXED_TIMESTEP as our delta time
        g_game_state.player->update(FIXED_TIMESTEP, g_game_state.platforms,PLATFORM_COUNT);
        
        glm::vec3 movePlatformPos = g_game_state.platforms[3].get_position();
        glm::vec3 movePlatformVel = g_game_state.platforms[3].get_velocity();

        movePlatformPos += movePlatformVel * FIXED_TIMESTEP;

        if (movePlatformPos.x > 4.0f)
        {
            movePlatformPos.x = 4.0f; // clamp
            movePlatformVel.x = -movePlatformVel.x;
        }
        else if (movePlatformPos.x < -4.0f)
        {
            movePlatformPos.x = -4.0f; // clamp
            movePlatformVel.x = -movePlatformVel.x;
        }

        g_game_state.platforms[3].set_position(movePlatformPos);
        g_game_state.platforms[3].set_velocity(movePlatformVel);

        g_game_state.platforms[3].update(FIXED_TIMESTEP, nullptr, 0);

        glm::vec3 movePlatformPos2 = g_game_state.platforms[4].get_position();
        glm::vec3 movePlatformVel2 = g_game_state.platforms[4].get_velocity();

        movePlatformPos2 += movePlatformVel2 * FIXED_TIMESTEP;

        if (movePlatformPos2.x > 5.0f)
        {
            movePlatformPos2.x = 5.0f; // clamp
            movePlatformVel2.x = -movePlatformVel2.x;
        }
        else if (movePlatformPos2.x < -5.0f)
        {
            movePlatformPos2.x = -5.0f; // clamp
            movePlatformVel2.x = -movePlatformVel2.x;
        }

        g_game_state.platforms[4].set_position(movePlatformPos2);
        g_game_state.platforms[4].set_velocity(movePlatformVel2);

        g_game_state.platforms[4].update(FIXED_TIMESTEP, nullptr, 0);

        glm::vec3 movePlatformPos3 = g_game_state.platforms[5].get_position();
        glm::vec3 movePlatformVel3 = g_game_state.platforms[5].get_velocity();

        movePlatformPos3 += movePlatformVel3 * FIXED_TIMESTEP;

        if (movePlatformPos3.x > 5.0f)
        {
            movePlatformPos3.x = 4.0f; // clamp
            movePlatformVel3.x = -movePlatformVel.x;
        }
        else if (movePlatformPos3.x < -4.0f)
        {
            movePlatformPos3.x = -4.0f; // clamp
        
            movePlatformVel3.x = -movePlatformVel3.x;
        }

        g_game_state.platforms[5].set_position(movePlatformPos3);
        g_game_state.platforms[5].set_velocity(movePlatformVel3);

        g_game_state.platforms[5].update(FIXED_TIMESTEP, nullptr, 0);


        for (int i = 0; i < PLATFORM_COUNT; i++)
        {
            if (g_game_state.player->check_collision(&g_game_state.platforms[i]))
            {
                g_Over = true;
                if (i == 3 || i==4 || i==5) {
                    std::cout << "MISSION ACCOMPLISHED!" << std::endl;
                    mission = 1;
                }
                else {
                    std::cout << "MISSION FAILED!" << std::endl;
                    mission = 2;
                }
       
                break;
            }
        }

        delta_time -= FIXED_TIMESTEP;
    }

    g_time_accumulator = delta_time;
}

void draw_winner() {
    if (!g_Over) return;

    if (mission == 1) {
        draw_text(&g_shader_program, g_game_state.font_texture_id, "Mission Completed!", 0.5f, 0.05f,
            glm::vec3(-3.5f, 2.0f, 0.0f));
    }

    if (mission == 2) {
        draw_text(&g_shader_program, g_game_state.font_texture_id, "Mission Failed!", 0.5f, 0.05f,
            glm::vec3(-3.5f, 2.0f, 0.0f));
    }
}


void render()
{
    // ————— GENERAL ————— //
    glClear(GL_COLOR_BUFFER_BIT);

    // ————— PLAYER ————— //
    g_game_state.player->render(&g_shader_program);

    // ————— PLATFORM ————— //
    for (int i = 0; i < PLATFORM_COUNT; i++)
        g_game_state.platforms[i].render(&g_shader_program);


    float currentFuel = g_game_state.player->get_fuel();
    std::string fuelText = "FUEL: " + std::to_string((int)currentFuel);

    draw_text(
        &g_shader_program,
        g_game_state.font_texture_id,
        fuelText,
        0.5f,   
        -0.25f, 
        glm::vec3(-4.8f, 3.3f, 0.0f)); 

    draw_winner();


    // ————— GENERAL ————— //
    SDL_GL_SwapWindow(g_display_window);
}

void shutdown()
{
    SDL_Quit();

    delete   g_game_state.player;
    delete[] g_game_state.platforms;
}


int main(int argc, char* argv[])
{
    initialise();

    while (g_app_status == RUNNING)
    {
        process_input();
        update();
        render();
    }

    shutdown();
    return 0;
}

void draw_text(ShaderProgram* program, GLuint font_texture_id, std::string text,
    float font_size, float spacing, glm::vec3 position)
{
    // Scale the size of the fontbank in the UV-plane
    // We will use this for spacing and positioning
    float width = 1.0f / FONTBANK_SIZE;
    float height = 1.0f / FONTBANK_SIZE;

    // Instead of having a single pair of arrays, we'll have a series of pairs—one for
    // each character. Don't forget to include <vector>!
    std::vector<float> vertices;
    std::vector<float> texture_coordinates;

    // For every character...
    for (int i = 0; i < text.size(); i++) {
        // 1. Get their index in the spritesheet, as well as their offset (i.e. their
        //    position relative to the whole sentence)
        int spritesheet_index = (int)text[i];  // ascii value of character
        float offset = (font_size + spacing) * i;

        // 2. Using the spritesheet index, we can calculate our U- and V-coordinates
        float u_coordinate = (float)(spritesheet_index % FONTBANK_SIZE) / FONTBANK_SIZE;
        float v_coordinate = (float)(spritesheet_index / FONTBANK_SIZE) / FONTBANK_SIZE;

        // 3. Inset the current pair in both vectors
        vertices.insert(vertices.end(), {
            offset + (-0.5f * font_size), 0.5f * font_size,
            offset + (-0.5f * font_size), -0.5f * font_size,
            offset + (0.5f * font_size), 0.5f * font_size,
            offset + (0.5f * font_size), -0.5f * font_size,
            offset + (0.5f * font_size), 0.5f * font_size,
            offset + (-0.5f * font_size), -0.5f * font_size,
            });

        texture_coordinates.insert(texture_coordinates.end(), {
            u_coordinate, v_coordinate,
            u_coordinate, v_coordinate + height,
            u_coordinate + width, v_coordinate,
            u_coordinate + width, v_coordinate + height,
            u_coordinate + width, v_coordinate,
            u_coordinate, v_coordinate + height,
            });
    }

    // 4. And render all of them using the pairs
    glm::mat4 model_matrix = glm::mat4(1.0f);
    model_matrix = glm::translate(model_matrix, position);

    program->set_model_matrix(model_matrix);
    glUseProgram(program->get_program_id());

    glVertexAttribPointer(program->get_position_attribute(), 2, GL_FLOAT, false, 0,
        vertices.data());
    glEnableVertexAttribArray(program->get_position_attribute());
    glVertexAttribPointer(program->get_tex_coordinate_attribute(), 2, GL_FLOAT, false, 0,
        texture_coordinates.data());
    glEnableVertexAttribArray(program->get_tex_coordinate_attribute());

    glBindTexture(GL_TEXTURE_2D, font_texture_id);
    glDrawArrays(GL_TRIANGLES, 0, (int)(text.size() * 6));

    glDisableVertexAttribArray(program->get_position_attribute());
    glDisableVertexAttribArray(program->get_tex_coordinate_attribute());
}